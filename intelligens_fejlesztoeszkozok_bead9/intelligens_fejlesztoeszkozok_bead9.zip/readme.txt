v 001 - papíron megoldva
v 002 - papíron tisztázva
v 003 - papíron javítva x,y,z és kód + plotok
v 004 - papíron javítva, kód javítás
v 005 - kód javítva de nem látom miért nem helyes a plot.
v 006 - a kód javítva - a helyes kezdeti értékek nem fix paraméterek hanem az A*sin(omega * t) és A*omega*cos(omega*t)
v 007 - latex begépelve
v 008 - plot javítva
v 009 - plotok kezdeti ha kezdeti érték 0 hozzáadva
v 010 - plotok leírása hozzáadva a dokumentacohoz
v 011 - még több leírás
v 020 - hibametrika javítva