v 001  - a hibametrikánál nem tudom mi a "n" illetve delta, d/dt -t miből számoljak.
v 002  - a kódban beadva alpha, delta, beta értékek a rendszer és a közelítő inverz modellhez.
v 003  - kódban kiszervezve az értékek, a hibametrikához és a kinematikai blokkhoz kéne egy kis segítség, mert nem nagyon tudok velük elindulni
v 004  - átalakított rendszer blokkk, a hibametrika és a kinematikai blokk még mindig teljes homály
V 005  - átírtam a számítást az órait beírva
v 006  - átírtam a számítást az órait átírva
v 007  - átírva a kód a számítás alapján
v 008  - kódban kezdőértékek és súlyok beadva
v 009  - számításnál kinematikai blokk átírva
v 0010 - tisztázott számítás
v 0011 - alaphelyzet és nem alaphelyzet plotok
v 010  - kód javítva, de a fázistér még kicsit fura, nem tudom mitől ilyen, ötletem sincs
v 011  - latex dokumentálva
v 012  - 1,1 értékkel jó
v 013  - javított forma
v 014  - omega*t ből számolva ak iindulási pont
v 015  - egy +1 es hiba volt