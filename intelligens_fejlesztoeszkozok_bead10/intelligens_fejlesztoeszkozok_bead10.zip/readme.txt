v001 - órai kód átalakítva
v002 - latex dokumentació
v003 - kiegészítés dokumentacioban
v004 - kiegészítés dokumentacioban
v005 - kódban visszaállítás kezdeti feltétel nélküli állapotra
     - dokumentacio kiegeszitve kezdeti feltetel nelkuli plotokkal
v006 - ki kell fejteni, mi van az abaran.
v007 - q^N derivaltjat igy csinald \dot{q}^N igy jo helyre rakja a pontot (5),(10)